import React, { useEffect, useRef, useState } from "react";
import "../index.css";
import "../assets/css/TeamSection.css";
import AOS from "aos";
import "aos/dist/aos.css";

const teamMembers = [
  {
    image: "images/team-member-1.webp",
    name: "Karthick Ganesh",
    position: "Founder & CEO",
    bio: "A passionate leader focused on empowering the next generation of innovators with a strong vision for academic and practical excellence.",
    accent: "lead",
    socials: ["facebook", "twitter-x", "linkedin", "instagram"],
  },
  {
    image: "images/team-member-2.webp",
    name: "Harshini",
    position: "CTO & Co-Founder",
    bio: "A visionary mentor promoting entrepreneurship and innovation, supporting students from exploration to impactful execution.",
    accent: "core",
    socials: ["facebook", "twitter-x", "linkedin", "instagram"],
  },
];

export default function TeamSection() {
  const sectionRef = useRef(null);

  const [animateName, setAnimateName] = useState(false);
  const [animateImage, setAnimateImage] = useState(false);
  const [animateBio, setAnimateBio] = useState(false);

  useEffect(() => {
    AOS.init({
      duration: 900,
      once: true,
      offset: 80,
      easing: "ease-out-cubic",
    });
  }, []);

  useEffect(() => {
    const section = sectionRef.current;

    if (!section || typeof window === "undefined") {
      return undefined;
    }

    const timers = [];

    const setAnimationState = (isActive) => {
      timers.forEach((timer) => window.clearTimeout(timer));
      timers.length = 0;

      if (!isActive) {
        setAnimateName(false);
        setAnimateImage(false);
        setAnimateBio(false);
        return;
      }

      timers.push(
        window.setTimeout(() => setAnimateName(true), 100)
      );

      timers.push(
        window.setTimeout(() => setAnimateImage(true), 300)
      );

      timers.push(
        window.setTimeout(() => setAnimateBio(true), 500)
      );
    };

    const observer = new IntersectionObserver(
      ([entry]) => {
        setAnimationState(entry.isIntersecting);
      },
      {
        threshold: 0.3,
      }
    );

    observer.observe(section);

    return () => {
      timers.forEach((timer) => window.clearTimeout(timer));
      observer.disconnect();
    };
  }, []);

  return (
    <section className="team-section" ref={sectionRef}>
      <div className="container">

        {/* ==================================================
            TEAM SECTION HEADER
            ================================================== */}
        <div
          className="team-section-header"
          data-aos="fade-up"
          data-aos-delay="100"
        >
          <span className="team-section-badge">
            <span className="team-badge-dot"></span>
            OUR TEAM MEMBERS
          </span>

          <h2 className="team-section-title">
            Meet the{" "}
            <span className="team-title-highlight">
              Creative Minds
            </span>
          </h2>

          <div className="team-title-line"></div>

          <p className="team-section-desc">
            The leadership team behind Projenius combines product thinking,
            engineering depth, and practical execution. We are keeping this
            section focused on the core faces of the company for now.
          </p>
        </div>

        {/* ==================================================
            TEAM MEMBERS
            ================================================== */}
        <div className="team-grid-top">

          {teamMembers.map((member, index) => (
            <article
              className="team-card"
              key={member.name}
              data-aos="fade-up"
              data-aos-delay={200 + index * 150}
            >

              {/* TEXT */}
              <div className="team-card-body">

                <h3
                  className={`team-member-name ${
                    animateName ? "team-name-in" : ""
                  }`}
                >
                  {member.name}
                </h3>

                <p
                  className={`team-member-role ${
                    animateName ? "team-role-in" : ""
                  }`}
                >
                  {member.position}
                </p>

                {member.bio && (
                  <p
                    className={`team-member-bio ${
                      animateBio ? "team-bio-in" : ""
                    }`}
                  >
                    {member.bio}
                  </p>
                )}

              </div>

              {/* IMAGE */}
              <div className="team-card-photo">

                <img
                  className={
                    animateImage ? "team-image-in" : ""
                  }
                  src={member.image}
                  alt={member.name}
                />

                {/* SOCIAL ICONS */}
                <div className="team-card-socials">

                  {member.socials.map((platform) => (
                    <a
                      href="#"
                      key={platform}
                      aria-label={`${member.name} ${platform}`}
                    >
                      <i className={`bi bi-${platform}`}></i>
                    </a>
                  ))}

                </div>

              </div>

            </article>
          ))}

        </div>

      </div>
    </section>
  );
}