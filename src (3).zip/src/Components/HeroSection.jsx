import React, { useEffect, useState } from "react";
import "../assets/css/HeroSection.css";

const slides = [
    {
        bg: "/images/projenius-banner.webp",
        thumb: "/images/projenius-banner.webp",
        buttonText: "Explore Courses",
    },
    {
        bg: "/images/projenius-banner-1.webp",
        thumb: "/images/projenius-banner-1.webp",
        buttonText: "Explore IoT",
    },
    {
        bg: "/images/projenius-banner-2.webp",
        thumb: "/images/projenius-banner-2.webp",
        buttonText: "Explore Web Design",
    },
    {
        bg: "/images/projenius-banner-3.webp",
        thumb: "/images/projenius-banner-3.webp",
        buttonText: "Explore Workshops",
    },
    {
        bg: "/images/projenius-banner-4.webp",
        thumb: "/images/projenius-banner-4.webp",
        buttonText: "Explore Software",
    },
];

const PARTICLES = [
    { size: 10, top: "18%", left: "12%", duration: "5.2s", delay: "0s" },
    { size: 6, top: "65%", left: "8%", duration: "6.8s", delay: "1s" },
    { size: 14, top: "35%", left: "88%", duration: "7.1s", delay: "0.4s" },
    { size: 8, top: "75%", left: "82%", duration: "5.6s", delay: "2s" },
    { size: 5, top: "50%", left: "55%", duration: "4.9s", delay: "0.8s" },
    { size: 12, top: "22%", left: "70%", duration: "6.3s", delay: "1.5s" },
];


function DotIndicators({ total, active, onDotClick }) {
    return (
        <div
            style={{
                display: "flex",
                gap: "8px",
                justifyContent: "center",
                marginTop: "24px",
            }}
        >
            {Array.from({ length: total }).map((_, i) => (
                <button
                    key={i}
                    className={`hero-slide-dot ${i === active ? "active" : ""}`}
                    aria-label={`Go to slide ${i + 1}`}
                    onClick={() => onDotClick(i)}
                    style={{
                        width: "10px",
                        height: "10px",
                        borderRadius: "50%",
                        border: "none",
                        background:
                            i === active
                                ? "rgb(0, 224, 211)"
                                : "rgba(255,255,255,0.4)",
                        cursor: "pointer",
                        padding: 0,
                        transition:
                            "width 0.35s ease, background 0.35s ease",
                    }}
                />
            ))}
        </div>
    );
}

export default function HeroSection() {
    const [activeSlide, setActiveSlide] = useState(0);
    const [isMobile, setIsMobile] = useState(false);


    useEffect(() => {
        const mq = window.matchMedia("(max-width: 991px)");
        setIsMobile(mq.matches);

        const handler = (e) => {
            setIsMobile(e.matches);
        };

        mq.addEventListener("change", handler);
        return () => mq.removeEventListener("change", handler);
    }, []);

    useEffect(() => {
        slides.forEach((slide) => {
            const bgImage = new Image();
            bgImage.src = slide.bg;
        });
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            setActiveSlide((prev) =>
                prev === slides.length - 1 ? 0 : prev + 1
            );
        }, 3800);

        return () => clearInterval(interval);
    }, []);

    const handleThumbClick = (index) => {
        setActiveSlide(index);
    };

    const getThumbOffset = (index) =>
        (index - activeSlide + slides.length) % slides.length;

    return (
        <div
            className="hero-wrapper"
            style={{
                backgroundImage: `
                    linear-gradient(
                        135deg,
                        rgba(18,25,41,0.92),
                        rgba(18,25,41,0.9)
                    ),
                    url(${slides[activeSlide].bg})
                `,
            }}
        >
            {PARTICLES.map((p, i) => (
                <span
                    key={i}
                    className="hero-particle"
                    style={{
                        width: p.size,
                        height: p.size,
                        top: p.top,
                        left: p.left,
                        animationDuration: p.duration,
                        animationDelay: p.delay,
                    }}
                />
            ))}

            <section className="hero container">
                <div className="row align-items-center">
                    <div className="col-lg-7 col-12">
                        <h3 className="subheading">
                            We Design, Develop &amp; Deliver Impactful Technology
                        </h3>

                        <h1 className="heading">
                            <span className="hero-heading-line hero-heading-line-1">
                                Building{" "}
                                <span
                                    className="smart-solutions"
                                    style={{
                                        color: "rgb(0, 255, 242)",
                                        background: "none",
                                        backgroundImage: "none",
                                        WebkitTextFillColor: "rgb(0, 255, 242)",
                                        animation: "none",
                                    }}
                                >
                                    Smart Solutions
                                </span>
                            </span>

                            <span className="hero-heading-line hero-heading-line-2">
                                with AI, IoT &amp; Innovation
                            </span>
                        </h1>

                        <p className="description mt-3">
                            Projenius is a technology-driven startup focused on building innovative solutions in AI, IoT, Software Development, and Product Engineering.
                        </p>

                        <div className="hero-buttons">
                            <a
                                href="#"
                                className="btn"
                                style={{
                                    backgroundColor: "rgb(0, 224, 211)",
                                    color: "rgb(0, 0, 0)",
                                }}
                            >
                                <span
                                    className="btn-content"
                                    key={activeSlide}
                                    style={{ color: "rgb(0, 0, 0)" }}
                                >
                                    {slides[activeSlide].buttonText}
                                </span>
                            </a>
                        </div>

                        {isMobile && (
                            <DotIndicators
                                total={slides.length}
                                active={activeSlide}
                                onDotClick={handleThumbClick}
                            />
                        )}
                    </div>

                    <div className="col-lg-5 d-none d-lg-flex justify-content-center">
                        <div className="thumb-wrapper">
                            {slides.map((slide, realIndex) => {
                                const offset = getThumbOffset(realIndex);
                                const isVisible = offset < 3;

                                return (
                                    <img
                                        key={realIndex}
                                        src={slide.thumb}
                                        alt={`slide thumbnail ${realIndex + 1}`}
                                        className={`
                                            thumb-img
                                            thumb-slot-${Math.min(offset, 3)}
                                            ${isVisible ? "visible" : "hidden"}
                                            ${activeSlide === realIndex ? "active" : ""}
                                        `}
                                        style={{
                                            borderRadius: "50%",
                                            border:
                                                activeSlide === realIndex
                                                    ? "4px solid rgb(0, 224, 211)"
                                                    : "none",
                                            boxShadow:
                                                activeSlide === realIndex
                                                    ? "0 0 22px rgba(0, 224, 211, 0.35)"
                                                    : "none",
                                            objectFit: "cover",
                                            transition:
                                                "border 0.35s ease, box-shadow 0.35s ease, transform 0.35s ease",
                                        }}
                                        onClick={() => handleThumbClick(realIndex)}
                                        decoding="async"
                                    />
                                );
                            })}
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}